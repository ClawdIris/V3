-- ============================================================================
-- 00_auth_stub.sql
-- ----------------------------------------------------------------------------
-- ONLY needed if you are running against a plain Postgres instance instead of
-- the Supabase CLI. `supabase start` already provides the auth schema,
-- auth.users, auth.uid(), and the anon / authenticated / service_role roles.
-- DO NOT run this against a real Supabase project.
-- ============================================================================

create extension if not exists pgcrypto;

create schema if not exists auth;

create table if not exists auth.users (
  id    uuid primary key default gen_random_uuid(),
  email text
);

-- Mimics Supabase's auth.uid(): reads the current user id from a session GUC.
create or replace function auth.uid()
 returns uuid
 language sql
 stable
as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;

do $$ begin create role anon;          exception when duplicate_object then null; end $$;
do $$ begin create role authenticated; exception when duplicate_object then null; end $$;
do $$ begin create role service_role;  exception when duplicate_object then null; end $$;
