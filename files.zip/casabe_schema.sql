-- ============================================================================
-- Casabe Konnect — Schema (structure only; NO customer data)
-- ----------------------------------------------------------------------------
-- Reconstructed from the live "public" schema for local development.
-- Multi-tenant model: every row is scoped by tenant_id -> public.companies(id).
-- RLS is enabled on every table; access is decided by the helper functions
-- (current_tenant_id, get_user_role, is_hq, is_office, is_member, ...).
--
-- Apply order matters: tables -> helper functions -> RLS policies.
-- The two temporary "_snapshot_*" backup tables that exist in production are
-- intentionally NOT included here — they are transient and not part of the app.
--
-- Requires the Supabase "auth" schema (auth.users, auth.uid()) and the roles
-- anon / authenticated / service_role. On `supabase start` these already exist.
-- For a plain Postgres instance, run 00_auth_stub.sql first (see setup guide).
-- ============================================================================

begin;

-- ----------------------------------------------------------------------------
-- 1. Tenants and org structure
-- ----------------------------------------------------------------------------

create table public.companies (
  id                          text primary key,
  name                        text not null,
  plan                        text not null default 'pilot',
  active                      boolean not null default true,
  created_at                  timestamptz not null default now(),
  slug                        text,
  legal_name                  text,
  display_name                text,
  status                      text default 'active'
                                check (status = any (array['active','inactive','suspended','trial'])),
  tier                        text
                                check (tier = any (array['pilot','starter','growth','enterprise'])),
  branding                    jsonb default '{}'::jsonb,
  settings                    jsonb default '{}'::jsonb,
  whatsapp_business_account_id text,
  whatsapp_phone_number_id    text,
  whatsapp_display_phone      text,
  whatsapp_status             text default 'not_connected'
                                check (whatsapp_status = any (array['not_connected','pending','connected','suspended'])),
  stripe_account_id           text,
  stripe_status               text default 'not_connected'
                                check (stripe_status = any (array['not_connected','pending','connected','restricted'])),
  updated_at                  timestamptz default now()
);
comment on table public.companies is 'Tenants. One row per customer organization.';

create table public.offices (
  id               uuid primary key default gen_random_uuid(),
  tenant_id        text not null references public.companies(id),
  slug             text not null,
  name             text not null,
  address          text,
  phone            text,
  is_active        boolean not null default true,
  commission_model jsonb not null default '{}'::jsonb,
  notes            text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
comment on table public.offices is 'Owned operating locations per tenant. Partner intake sources live in public.partners.';
comment on column public.offices.commission_model is 'JSONB. Owned: {type:"owned", retain_revenue_percent, office_commission_percent}.';

create table public.partners (
  id                uuid primary key default gen_random_uuid(),
  tenant_id         text not null references public.companies(id),
  slug              text not null,
  name              text not null,
  parent_partner_id uuid references public.partners(id) on delete set null,
  address           text,
  phone             text,
  is_active         boolean not null default true,
  commission_model  jsonb not null default '{}'::jsonb,
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
comment on table public.partners is 'External intake/referral/forwarding sources per tenant. Distinct from owned offices.';
comment on column public.partners.commission_model is 'JSONB. e.g. {type:"percentage", percentage:18} or {type:"per_box", rates:{...}}.';

create table public.members (
  id                  uuid primary key default gen_random_uuid(),
  tenant_id           text not null references public.companies(id),
  user_id             uuid not null references auth.users(id),
  role                text not null default 'dispatcher',
  display_name        text,
  active              boolean not null default true,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  app_role            text check (app_role is null or (app_role = any (array['hq','office','driver','customer']))),
  office_id           uuid references public.offices(id),
  driver_id           uuid,
  assigned_partner_id uuid references public.partners(id),
  last_seen_at        timestamptz,
  metadata            jsonb not null default '{}'::jsonb
);
comment on table public.members is 'Maps auth.users to a tenant + role. app_role (hq|office|driver|customer) drives RLS.';
comment on column public.members.app_role is 'Normalized role for RLS. Coexists with legacy role column.';
comment on column public.members.office_id is 'For app_role=office members: their assigned office. NULL otherwise.';

-- ----------------------------------------------------------------------------
-- 2. Orders (core entity). Composite PK (id, tenant_id).
-- ----------------------------------------------------------------------------

create table public.orders (
  id                    text not null,
  tenant_id             text not null references public.companies(id),
  data                  jsonb not null,
  updated_at            timestamptz not null default now(),
  office_id             uuid references public.offices(id),
  partner_id            uuid references public.partners(id),
  pickup_location       text check ((pickup_location = any (array['office','client_house'])) or pickup_location is null),
  lat                   double precision,
  lon                   double precision,
  coordinate_status     text default 'missing'
                          check (coordinate_status = any (array['missing','geocoded','low_confidence','manual_override'])),
  coordinate_updated_at timestamptz,
  coordinate_updated_by text,
  sms_opted_in          boolean not null default false,
  whatsapp_opted_in     boolean not null default false,
  consent_recorded_at   timestamptz,
  consent_recorded_by   text,
  primary key (id, tenant_id)
);
comment on table public.orders is 'Core order entity. Most order fields live in the data JSONB column. Scoped by composite PK (id, tenant_id).';

-- ----------------------------------------------------------------------------
-- 3. Helper functions (must exist before policies and before tables whose
--    column DEFAULTs call current_tenant_id()).
-- ----------------------------------------------------------------------------

create or replace function public.current_tenant_id()
 returns text
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  select tenant_id from public.members
  where user_id = auth.uid() and active = true
  order by created_at limit 1;
$function$;

create or replace function public.get_user_role()
 returns text
 language plpgsql
 security definer
 set search_path to ''
as $function$
declare
  user_role text;
begin
  select coalesce(app_role, role) into user_role
  from public.members
  where user_id = auth.uid()
    and active = true
  order by created_at
  limit 1;
  return coalesce(user_role, 'anonymous');
end;
$function$;

create or replace function public.get_user_office_ids()
 returns uuid[]
 language plpgsql
 security definer
 set search_path to ''
as $function$
begin
  return array(
    select office_id from public.members
    where user_id = auth.uid()
      and active = true
      and tenant_id = current_tenant_id()
      and office_id is not null
  );
end;
$function$;

create or replace function public.is_hq()
 returns boolean
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  select exists (
    select 1 from public.members
    where user_id = auth.uid() and active = true and app_role = 'hq'
  );
$function$;

create or replace function public.is_office()
 returns boolean
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  select exists (
    select 1 from public.members
    where user_id = auth.uid() and active = true and app_role = 'office'
  );
$function$;

create or replace function public.is_member(p_tenant_id text)
 returns boolean
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  select exists (
    select 1 from members
    where tenant_id = p_tenant_id
      and user_id   = auth.uid()
      and active    = true
  );
$function$;

create or replace function public.is_admin(p_tenant_id text)
 returns boolean
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  select exists (
    select 1 from members
    where tenant_id = p_tenant_id
      and user_id   = auth.uid()
      and active    = true
      and role in ('owner', 'admin')
  );
$function$;

create or replace function public.can_access_order(p_order_id text)
 returns boolean
 language sql
 stable security definer
 set search_path to 'public'
as $function$
  with me as (
    select tenant_id, app_role, user_id
    from public.members
    where user_id = auth.uid() and active = true
    order by created_at limit 1
  ),
  target as (
    select tenant_id as order_tenant,
           data->>'assignedDriverUserId' as assigned_driver_user_id
    from public.orders where id = p_order_id
  )
  select coalesce(
    (select me.tenant_id = target.order_tenant
       and (me.app_role in ('hq', 'office')
         or (me.app_role = 'driver'
             and target.assigned_driver_user_id = me.user_id::text))
     from me, target),
    false
  );
$function$;

-- ----------------------------------------------------------------------------
-- 4. Box-level + operational tables
-- ----------------------------------------------------------------------------

create table public.box_orders (
  id                uuid primary key default gen_random_uuid(),
  tenant_id         text not null default current_tenant_id(),
  order_id          text not null,
  box_number        integer not null,
  office_id         uuid,
  driver_id         uuid,
  box_type          text not null default 'standard',
  dimensions        jsonb,
  weight_lbs        numeric,
  status            text not null default 'created'
                      check (status = any (array['created','assigned','picked_up','in_transit','scanned','held','delivered','completed','failed','returned'])),
  status_updated_at timestamptz not null default now(),
  status_updated_by uuid,
  label_printed_at  timestamptz,
  label_printed_by  uuid,
  barcode           text unique,
  scanned_at        timestamptz,
  scanned_by        uuid,
  delivered_at      timestamptz,
  delivered_by      uuid,
  signature_url     text,
  delivery_notes    text,
  created_at        timestamptz not null default now(),
  created_by        uuid default auth.uid(),
  updated_at        timestamptz not null default now(),
  updated_by        uuid,
  metadata          jsonb default '{}'::jsonb,
  foreign key (order_id, tenant_id) references public.orders(id, tenant_id)
);
comment on table public.box_orders is 'Normalized box-level data. Separates box operations from order-level operations.';

create table public.shipments (
  id         text not null,
  tenant_id  text not null references public.companies(id),
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (id, tenant_id)
);

create table public.claims (
  id         text not null,
  tenant_id  text not null references public.companies(id),
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (id, tenant_id)
);

create table public.receipts (
  id         text not null,
  tenant_id  text not null references public.companies(id),
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (id, tenant_id)
);

create table public.receivers (
  id         text not null,
  tenant_id  text not null,
  data       jsonb,
  updated_at timestamptz default now(),
  primary key (id, tenant_id)
);

create table public.tenant_settings (
  id         text primary key,
  tenant_id  text not null references public.companies(id),
  config_key text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.box_status_log (
  id                  text primary key default (gen_random_uuid())::text,
  tenant_id           text not null,
  order_id            text not null,
  sub_id              text not null,
  old_order_status    text,
  new_order_status    text,
  old_shipment_status text,
  new_shipment_status text,
  changed_fields      text[],
  user_id             text,
  user_name           text,
  ts                  timestamptz not null default now(),
  source              text not null default 'manual_order_edit',
  session_id          text
);

create table public.send_log (
  id              text primary key default (gen_random_uuid())::text,
  tenant_id       text not null,
  order_id        text not null,
  phone           text,
  channels        text[],
  status          text not null,
  results         jsonb,
  error           text,
  triggered_by    text,
  ts              timestamptz not null default now(),
  source          text,
  target_role     text,
  target_phone    text,
  sender_name     text,
  tracking_number text,
  box_id          text,
  message_body    text
);

create table public.qb_sync_log (
  id             text primary key default (gen_random_uuid())::text,
  tenant_id      text not null,
  entity_type    text not null,
  local_id       text not null,
  remote_id      text,
  sync_direction text not null default 'push',
  sync_status    text not null default 'pending',
  error          text,
  qb_realm_id    text,
  ts             timestamptz not null default now(),
  synced_at      timestamptz
);

create table public.campaigns (
  id           uuid primary key default gen_random_uuid(),
  tenant_id    text not null,
  name         text not null,
  channel      text not null check (channel = any (array['whatsapp','sms','email','multi'])),
  audience_key text not null,
  status       text not null default 'draft'
                 check (status = any (array['draft','scheduled','sending','sent','partial','failed','cancelled'])),
  created_by   uuid,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  sent_at      timestamptz,
  sent_count   integer not null default 0,
  failed_count integer not null default 0,
  data         jsonb not null default '{}'::jsonb
);
comment on table public.campaigns is 'Marketing campaigns per tenant. Phase 1 = drafts only.';

create table public.activity_log (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     text not null default current_tenant_id(),
  order_id      text,
  box_id        uuid references public.box_orders(id),
  user_id       uuid references auth.users(id),
  activity_type text not null
                  check (activity_type = any (array['order_created','order_updated','order_deleted','order_assigned','box_created','box_updated','box_deleted','box_scanned','box_assigned','status_changed','invoice_created','invoice_sent','payment_received','user_login','user_logout','permissions_changed','settings_updated','system_event','error','warning'])),
  action        text not null check (action = any (array['create','read','update','delete','scan','assign','send','receive'])),
  resource_type text not null check (resource_type = any (array['order','box','invoice','payment','user','office','settings','system'])),
  description   text not null,
  old_data      jsonb,
  new_data      jsonb,
  ip_address    inet,
  user_agent    text,
  request_id    uuid,
  metadata      jsonb default '{}'::jsonb,
  created_at    timestamptz not null default now()
);
comment on table public.activity_log is 'Immutable append-only activity ledger (audit trail). Updates/deletes denied by RLS.';

create table public.payments (
  id                       uuid primary key default gen_random_uuid(),
  order_id                 text not null,
  tenant_id                text not null default current_tenant_id(),
  amount_cents             integer not null check (amount_cents > 0),
  currency                 text not null default 'USD'
                             check (currency = any (array['USD','EUR','GBP','CAD','MXN'])),
  payment_method           text not null,
  status                   text not null default 'pending'
                             check (status = any (array['pending','processing','completed','failed','refunded','cancelled'])),
  stripe_payment_intent_id text,
  stripe_charge_id         text,
  stripe_payment_link_id   text,
  reference_number         text,
  payer_name               text,
  payer_email              text,
  payer_phone              text,
  created_at               timestamptz not null default now(),
  processed_at             timestamptz,
  expires_at               timestamptz,
  metadata                 jsonb default '{}'::jsonb,
  notes                    text,
  created_by               uuid not null,
  processed_by             uuid,
  foreign key (order_id, tenant_id) references public.orders(id, tenant_id)
);
comment on table public.payments is 'Payment transaction records with Stripe integration and multi-method support.';

create table public.payment_receipts (
  id                uuid primary key default gen_random_uuid(),
  payment_id        uuid not null references public.payments(id),
  order_id          text not null,
  receipt_number    text not null unique,
  receipt_date      date not null,
  receipt_time      time not null,
  amount_cents      integer not null,
  amount_display    text not null,
  payment_method    text not null,
  payment_reference text,
  receipt_text      text not null,
  receipt_html      text,
  receipt_pdf_url   text,
  receipt_pdf_bytes bytea,
  sent_via          text[] check (sent_via is null or array_length(sent_via, 1) > 0),
  sms_sent_at       timestamptz,
  sms_phone         text,
  whatsapp_sent_at  timestamptz,
  whatsapp_number   text,
  email_sent_at     timestamptz,
  email_address     text,
  created_at        timestamptz not null default now(),
  created_by        uuid not null
);

create table public.invoices (
  id                  uuid primary key default gen_random_uuid(),
  order_id            text not null,
  tenant_id           text not null default current_tenant_id(),
  invoice_number      text not null unique,
  invoice_date        date not null,
  shipper_name        text not null,
  shipper_address     text,
  shipper_phone       text,
  shipper_email       text,
  recipient_name      text not null,
  recipient_address   text,
  recipient_phone     text,
  recipient_email     text,
  service_type        text,
  pickup_location     text,
  dropoff_address     text,
  num_boxes           integer not null,
  total_weight_lbs    numeric,
  subtotal_cents      integer not null default 0,
  shipping_cost_cents integer not null default 0,
  tax_cents           integer not null default 0,
  discount_cents      integer default 0,
  total_cents         integer not null check (total_cents >= 0),
  status              text not null default 'draft'
                        check (status = any (array['draft','sent','viewed','paid','archived','cancelled'])),
  invoice_sent_at     timestamptz,
  payment_received_at timestamptz,
  invoice_html        text,
  invoice_pdf_url     text,
  invoice_pdf_bytes   bytea,
  notes               text,
  metadata            jsonb default '{}'::jsonb,
  created_at          timestamptz not null default now(),
  created_by          uuid not null,
  updated_at          timestamptz not null default now(),
  updated_by          uuid,
  office_id           uuid,
  foreign key (order_id, tenant_id) references public.orders(id, tenant_id)
);
comment on table public.invoices is 'Itemized shipment invoices with multi-box support.';

create table public.invoice_items (
  id               uuid primary key default gen_random_uuid(),
  invoice_id       uuid not null references public.invoices(id),
  box_id           uuid not null references public.box_orders(id),
  item_sequence    integer not null check (item_sequence > 0),
  description      text not null,
  box_type         text,
  box_dimensions   jsonb,
  box_weight_lbs   numeric,
  unit_price_cents integer not null,
  quantity         integer not null default 1 check (quantity > 0),
  line_total_cents integer not null,
  created_at       timestamptz not null default now(),
  created_by       uuid not null,
  metadata         jsonb default '{}'::jsonb
);

create table public.box_order_invoices (
  id                   uuid primary key default gen_random_uuid(),
  box_id               uuid not null references public.box_orders(id),
  invoice_id           uuid not null references public.invoices(id),
  included_at          timestamptz not null default now(),
  invoice_line_item_id uuid references public.invoice_items(id)
);
comment on table public.box_order_invoices is 'Junction table tracking box inclusion in invoices.';

create table public.tape_direct_records (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     text not null default current_tenant_id(),
  order_id      text,
  box_id        uuid references public.box_orders(id),
  enabled       boolean not null default true,
  vendor_name   text,
  cost          numeric,
  quantity      integer,
  notes         text,
  office_id     uuid,
  staff_user_id uuid,
  staff_email   text,
  status        text not null default 'active'
                  check (status = any (array['active','voided','archived'])),
  voided_at     timestamptz,
  voided_by     uuid,
  void_reason   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
comment on table public.tape_direct_records is 'Tape Direct procurement events. Archived/voided, never hard-deleted. cost visible to HQ/Office only (enforced in app).';

create table public.box_sale_records (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     text not null default current_tenant_id(),
  box_type      text not null check (box_type = any (array['small','medium','large','oversized','custom'])),
  quantity      integer not null check (quantity > 0),
  unit_cost     numeric not null,
  sale_price    numeric not null,
  total_revenue numeric generated always as ((quantity)::numeric * sale_price) stored,
  total_cost    numeric generated always as ((quantity)::numeric * unit_cost) stored,
  gross_margin  numeric generated always as (((quantity)::numeric * sale_price) - ((quantity)::numeric * unit_cost)) stored,
  margin_pct    numeric generated always as (
                  case when (sale_price = (0)::numeric) then (0)::numeric
                       else round((((sale_price - unit_cost) / sale_price) * (100)::numeric), 2)
                  end) stored,
  order_id      text,
  box_order_id  uuid references public.box_orders(id),
  office_id     uuid not null,
  staff_user_id uuid,
  staff_email   text,
  status        text not null default 'active'
                  check (status = any (array['active','voided','archived'])),
  voided_at     timestamptz,
  voided_by     uuid,
  void_reason   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
comment on table public.box_sale_records is 'Empty box sale transactions. Revenue/cost/margin are generated columns. Voided, never hard-deleted.';

create table public.messages (
  id                  uuid primary key default gen_random_uuid(),
  tenant_id           text not null default current_tenant_id(),
  order_id            text,
  customer_id         uuid,
  recipient_phone     text not null,
  channel             text not null check (channel = any (array['sms','whatsapp'])),
  template_key        text not null,
  rendered_body       text not null,
  status              text not null default 'draft'
                        check (status = any (array['draft','queued','blocked','sent','failed','cancelled'])),
  provider_message_id text,
  error_message       text,
  created_by          text not null,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  sent_at             timestamptz,
  foreign key (order_id, tenant_id) references public.orders(id, tenant_id)
);
comment on table public.messages is 'Outbound SMS/WhatsApp queue and log. Actual delivery happens via the sms-send Edge Function, not from this table.';

create table public.stripe_events (
  id             text primary key,
  event_type     text not null,
  order_id       text,
  tenant_id      text,
  payment_status text not null default 'processing',
  processed_at   timestamptz,
  raw_error      text,
  claimed_at     timestamptz not null default now()
);
comment on table public.stripe_events is 'Stripe webhook idempotency/processing ledger. Writable only by service_role.';

create table public.tracking_alert_consents (
  id                          uuid primary key default gen_random_uuid(),
  tenant_id                   text not null,
  order_id                    text not null,
  tracking_number             text not null,
  first_name                  text not null,
  last_name                   text not null,
  phone_e164                  text not null,
  zip_code                    text not null,
  transactional_sms_opted_in  boolean not null default false,
  marketing_sms_opted_in      boolean not null default false,
  consent_text_transactional  text not null,
  consent_text_marketing      text,
  consent_version             text not null,
  terms_url                   text not null,
  privacy_url                 text not null,
  source_url                  text not null,
  ip_hash                     text,
  user_agent                  text,
  created_at                  timestamptz not null default now(),
  revoked_at                  timestamptz,
  status                      text not null default 'active'
);

-- ----------------------------------------------------------------------------
-- 5. Enable Row Level Security on every table
-- ----------------------------------------------------------------------------

alter table public.companies              enable row level security;
alter table public.offices                enable row level security;
alter table public.partners               enable row level security;
alter table public.members                enable row level security;
alter table public.orders                 enable row level security;
alter table public.box_orders             enable row level security;
alter table public.shipments              enable row level security;
alter table public.claims                 enable row level security;
alter table public.receipts               enable row level security;
alter table public.receivers              enable row level security;
alter table public.tenant_settings        enable row level security;
alter table public.box_status_log         enable row level security;
alter table public.send_log               enable row level security;
alter table public.qb_sync_log            enable row level security;
alter table public.campaigns              enable row level security;
alter table public.activity_log           enable row level security;
alter table public.payments               enable row level security;
alter table public.payment_receipts       enable row level security;
alter table public.invoices               enable row level security;
alter table public.invoice_items          enable row level security;
alter table public.box_order_invoices     enable row level security;
alter table public.tape_direct_records    enable row level security;
alter table public.box_sale_records       enable row level security;
alter table public.messages               enable row level security;
alter table public.stripe_events          enable row level security;
alter table public.tracking_alert_consents enable row level security;

-- ----------------------------------------------------------------------------
-- 6. RLS policies
-- ----------------------------------------------------------------------------

-- companies
create policy "companies_member_read" on public.companies as permissive for select to public
  using (exists (select 1 from members where members.tenant_id = companies.id and members.user_id = auth.uid() and members.active = true));

-- offices
create policy "offices_hq_write" on public.offices as permissive for all to authenticated
  using (is_hq() and (tenant_id = current_tenant_id())) with check (is_hq() and (tenant_id = current_tenant_id()));
create policy "offices_member_read" on public.offices as permissive for select to authenticated
  using (is_member(tenant_id));

-- partners
create policy "partners_hq_write" on public.partners as permissive for all to authenticated
  using (is_hq() and (tenant_id = current_tenant_id())) with check (is_hq() and (tenant_id = current_tenant_id()));
create policy "partners_member_read" on public.partners as permissive for select to authenticated
  using (is_member(tenant_id));

-- members
create policy "members_admin_read" on public.members as permissive for select to public
  using (is_admin(tenant_id));
create policy "members_admin_write" on public.members as permissive for all to public
  using (is_admin(tenant_id)) with check (is_admin(tenant_id));
create policy "members_read_own" on public.members as permissive for select to public
  using (user_id = auth.uid());

-- orders
create policy "orders_driver_select" on public.orders as permissive for select to public
  using (is_member(tenant_id) and (get_user_role() = 'driver') and can_access_order(id));
create policy "orders_hq_office_select" on public.orders as permissive for select to public
  using (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')));
create policy "orders_hq_office_insert" on public.orders as permissive for insert to public
  with check (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')));
create policy "orders_hq_office_update" on public.orders as permissive for update to public
  using (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')))
  with check (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')));
create policy "orders_hq_office_delete" on public.orders as permissive for delete to public
  using (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')));

-- box_orders
create policy "hq_can_view_all_boxes" on public.box_orders as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "hq_can_create_boxes" on public.box_orders as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "hq_can_update_all_boxes" on public.box_orders as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))))
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "office_can_view_own_office_boxes" on public.box_orders as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "office_can_create_boxes" on public.box_orders as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "office_can_update_own_boxes" on public.box_orders as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())))
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "driver_can_view_assigned_boxes" on public.box_orders as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = 'driver') and (driver_id = auth.uid()));
create policy "driver_can_update_assigned_boxes" on public.box_orders as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = 'driver') and (driver_id = auth.uid()))
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = 'driver') and (driver_id = auth.uid()));
create policy "deny_box_delete" on public.box_orders as permissive for delete to public using (false);

-- shipments
create policy "shipments_member_all" on public.shipments as permissive for all to public
  using (is_member(tenant_id)) with check (is_member(tenant_id));
create policy "test_tenant_anon_read" on public.shipments as permissive for select to public using (tenant_id = 'test-tenant');
create policy "test_tenant_anon_insert" on public.shipments as permissive for insert to anon with check (tenant_id = 'test-tenant');
create policy "test_tenant_anon_update" on public.shipments as permissive for update to anon using (tenant_id = 'test-tenant') with check (tenant_id = 'test-tenant');

-- claims
create policy "claims_member_all" on public.claims as permissive for all to public
  using (is_member(tenant_id)) with check (is_member(tenant_id));
create policy "test_tenant_anon_read" on public.claims as permissive for select to public using (tenant_id = 'test-tenant');
create policy "test_tenant_anon_insert" on public.claims as permissive for insert to anon with check (tenant_id = 'test-tenant');
create policy "test_tenant_anon_update" on public.claims as permissive for update to anon using (tenant_id = 'test-tenant') with check (tenant_id = 'test-tenant');

-- receipts
create policy "receipts_member_all" on public.receipts as permissive for all to public
  using (is_member(tenant_id)) with check (is_member(tenant_id));
create policy "test_tenant_anon_read" on public.receipts as permissive for select to public using (tenant_id = 'test-tenant');
create policy "test_tenant_anon_insert" on public.receipts as permissive for insert to anon with check (tenant_id = 'test-tenant');
create policy "test_tenant_anon_update" on public.receipts as permissive for update to anon using (tenant_id = 'test-tenant') with check (tenant_id = 'test-tenant');

-- receivers (older pattern: tenant from a GUC)
create policy "tenant_isolation" on public.receivers as permissive for all to public
  using (tenant_id = current_setting('app.tenant_id', true));

-- tenant_settings
create policy "tenant_settings_member_all" on public.tenant_settings as permissive for all to public
  using (is_member(tenant_id)) with check (is_member(tenant_id));

-- box_status_log
create policy "box_status_log_hq_office_read" on public.box_status_log as permissive for select to authenticated
  using ((is_hq() or is_office()) and (tenant_id = current_tenant_id()));

-- send_log
create policy "send_log_hq_office_read" on public.send_log as permissive for select to authenticated
  using ((is_hq() or is_office()) and (tenant_id = current_tenant_id()));

-- qb_sync_log
create policy "qb_sync_log_hq_read" on public.qb_sync_log as permissive for select to authenticated
  using (is_hq() and (tenant_id = current_tenant_id()));

-- campaigns
create policy "campaigns_hq_office_select" on public.campaigns as permissive for select to authenticated
  using ((is_hq() or is_office()) and (tenant_id = current_tenant_id()));
create policy "campaigns_hq_office_insert" on public.campaigns as permissive for insert to authenticated
  with check ((is_hq() or is_office()) and (tenant_id = current_tenant_id()));
create policy "campaigns_hq_office_update" on public.campaigns as permissive for update to authenticated
  using ((is_hq() or is_office()) and (tenant_id = current_tenant_id()))
  with check ((is_hq() or is_office()) and (tenant_id = current_tenant_id()));
create policy "test_tenant_anon_read" on public.campaigns as permissive for select to public using (tenant_id = 'test-tenant');

-- activity_log (append-only)
create policy "hq_can_view_all_activities" on public.activity_log as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "office_can_view_office_activities" on public.activity_log as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (((resource_type = 'box') and (box_id in (select box_orders.id from box_orders where box_orders.office_id = any (get_user_office_ids())))) or ((resource_type = 'order') and (order_id in (select orders.id from orders where orders.office_id = any (get_user_office_ids())))) or (user_id = auth.uid())));
create policy "driver_can_view_assigned_activities" on public.activity_log as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = 'driver') and (((resource_type = 'box') and (box_id in (select box_orders.id from box_orders where box_orders.driver_id = auth.uid()))) or (user_id = auth.uid())));
create policy "authenticated_can_insert_activities" on public.activity_log as permissive for insert to public
  with check ((auth.uid() is not null) and (tenant_id = current_tenant_id()));
create policy "deny_activity_update" on public.activity_log as permissive for update to public using (false);
create policy "deny_activity_delete" on public.activity_log as permissive for delete to public using (false);

-- payments
create policy "payments_hq_select" on public.payments as permissive for select to authenticated
  using (get_user_role() = 'hq');
create policy "payments_office_select" on public.payments as permissive for select to authenticated
  using ((get_user_role() = 'office') and (order_id in (select orders.id from orders where (orders.office_id = any (get_user_office_ids())) and (orders.tenant_id = current_tenant_id()))));
create policy "payments_driver_select" on public.payments as permissive for select to authenticated
  using ((get_user_role() = 'driver') and (order_id in (select bo.order_id from box_orders bo where (bo.driver_id = auth.uid()) and (bo.tenant_id = current_tenant_id()))));
create policy "payments_insert" on public.payments as permissive for insert to authenticated
  with check (auth.uid() is not null);

-- payment_receipts
create policy "payment_receipts_hq_select" on public.payment_receipts as permissive for select to authenticated
  using (get_user_role() = 'hq');
create policy "payment_receipts_office_select" on public.payment_receipts as permissive for select to authenticated
  using ((get_user_role() = 'office') and (order_id in (select orders.id from orders where (orders.office_id = any (get_user_office_ids())) and (orders.tenant_id = current_tenant_id()))));
create policy "payment_receipts_insert" on public.payment_receipts as permissive for insert to authenticated
  with check (auth.uid() is not null);

-- invoices
create policy "invoices_hq_select" on public.invoices as permissive for select to authenticated
  using (get_user_role() = 'hq');
create policy "invoices_office_select" on public.invoices as permissive for select to authenticated
  using ((get_user_role() = 'office') and (order_id in (select orders.id from orders where (orders.office_id = any (get_user_office_ids())) and (orders.tenant_id = current_tenant_id()))));
create policy "invoices_insert" on public.invoices as permissive for insert to authenticated
  with check (auth.uid() is not null);
create policy "invoices_update" on public.invoices as permissive for update to authenticated
  using ((get_user_role() = 'hq') or (order_id in (select orders.id from orders where (orders.office_id = any (get_user_office_ids())) and (orders.tenant_id = current_tenant_id()))))
  with check ((get_user_role() = 'hq') or (order_id in (select orders.id from orders where (orders.office_id = any (get_user_office_ids())) and (orders.tenant_id = current_tenant_id()))));

-- invoice_items
create policy "invoice_items_hq" on public.invoice_items as permissive for all to authenticated
  using (get_user_role() = any (array['hq','admin','owner']));
create policy "invoice_items_office" on public.invoice_items as permissive for select to authenticated
  using ((get_user_role() = any (array['office','manager','dispatcher'])) and (invoice_id in (select invoices.id from invoices where (invoices.office_id = any (get_user_office_ids())) and (invoices.tenant_id = current_tenant_id()))));

-- box_order_invoices
create policy "box_order_invoices_hq" on public.box_order_invoices as permissive for all to authenticated
  using (get_user_role() = any (array['hq','admin','owner']));
create policy "box_order_invoices_office" on public.box_order_invoices as permissive for select to authenticated
  using ((get_user_role() = any (array['office','manager','dispatcher'])) and (invoice_id in (select invoices.id from invoices where (invoices.office_id = any (get_user_office_ids())) and (invoices.tenant_id = current_tenant_id()))));

-- tape_direct_records
create policy "td_hq_select" on public.tape_direct_records as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "td_hq_insert" on public.tape_direct_records as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "td_hq_update" on public.tape_direct_records as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))))
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "td_office_select" on public.tape_direct_records as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "td_office_insert" on public.tape_direct_records as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "td_office_update" on public.tape_direct_records as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())))
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "td_deny_delete" on public.tape_direct_records as permissive for delete to public using (false);

-- box_sale_records
create policy "bsr_hq_select" on public.box_sale_records as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "bsr_hq_insert" on public.box_sale_records as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "bsr_hq_update" on public.box_sale_records as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))))
  with check ((tenant_id = current_tenant_id()) and (is_hq() or (get_user_role() = any (array['hq','admin','owner']))));
create policy "bsr_office_select" on public.box_sale_records as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "bsr_office_insert" on public.box_sale_records as permissive for insert to public
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "bsr_office_update" on public.box_sale_records as permissive for update to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())))
  with check ((tenant_id = current_tenant_id()) and (get_user_role() = any (array['office','manager','dispatcher'])) and (office_id = any (get_user_office_ids())));
create policy "bsr_deny_delete" on public.box_sale_records as permissive for delete to public using (false);

-- messages
create policy "hq_messages_select" on public.messages as permissive for select to public
  using ((get_user_role() = 'hq') and (tenant_id = (select members.tenant_id from members where (members.user_id = auth.uid()) and (members.active = true) order by members.created_at limit 1)));
create policy "hq_messages_insert" on public.messages as permissive for insert to public
  with check ((get_user_role() = 'hq') and (tenant_id = (select members.tenant_id from members where (members.user_id = auth.uid()) and (members.active = true) order by members.created_at limit 1)));
create policy "hq_messages_update" on public.messages as permissive for update to public
  using ((get_user_role() = 'hq') and (tenant_id = (select members.tenant_id from members where (members.user_id = auth.uid()) and (members.active = true) order by members.created_at limit 1)))
  with check ((get_user_role() = 'hq') and (tenant_id = (select members.tenant_id from members where (members.user_id = auth.uid()) and (members.active = true) order by members.created_at limit 1)));
create policy "office_messages_select" on public.messages as permissive for select to public
  using ((tenant_id = current_tenant_id()) and (get_user_role() = 'office') and (order_id in (select orders.id from orders where orders.office_id = any (get_user_office_ids()))));
create policy "office_messages_insert" on public.messages as permissive for insert to public
  with check ((get_user_role() = 'office') and (tenant_id = (select members.tenant_id from members where (members.user_id = auth.uid()) and (members.active = true) order by members.created_at limit 1)) and (order_id in (select orders.id from orders where orders.office_id = any (get_user_office_ids()))));
create policy "deny_delete_messages" on public.messages as permissive for delete to public using (false);

-- stripe_events (service_role only; everyone else blocked)
create policy "service_only" on public.stripe_events as permissive for all to service_role using (true) with check (true);
create policy "block_others" on public.stripe_events as permissive for all to anon, authenticated using (false);

-- tracking_alert_consents
create policy "tac_hq_office_select" on public.tracking_alert_consents as permissive for select to authenticated
  using (is_member(tenant_id) and ((get_user_role() = 'hq') or (get_user_role() = 'office')));

commit;
