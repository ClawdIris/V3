# Casabe Konnect — Local Developer Setup

This package lets you work on Casabe Konnect against a **local copy of the
database** — same tables, same relationships, same row-level security rules —
**without any access to the production Supabase project or real customer data.**

## What's in here

| File | What it is |
|------|------------|
| `casabe_schema.sql` | The full database structure: tables, columns, constraints, helper functions, and all Row Level Security policies. **Structure only — no data.** |
| `casabe_seed.sql`   | Fake development data (one demo tenant with HQ / office / driver users, a couple offices/partners, a few orders and boxes). Everything in it is invented. |
| `00_auth_stub.sql`  | Only needed if you run on **plain Postgres** instead of the Supabase CLI. Creates a minimal `auth` schema so the policies work. |

## What you have access to (and what you don't)

- ✅ The complete schema and RLS logic — everything you need to build features.
- ✅ A working local database with realistic, fake data.
- ❌ No production Supabase credentials, no service-role/secret key.
- ❌ No real customer records.

This isn't about trust — building against production with live data is a bad
idea for anyone. Work locally; changes get reviewed and applied to production
separately.

---

## Recommended path: Supabase CLI

This matches how the project is actually run (migrations + local stack) and
gives you Studio, Auth, and the API locally.

1. **Install the CLI** (if you don't have it):
   ```bash
   npm install -g supabase   # or: brew install supabase/tap/supabase
   ```

2. **Start the local stack** from the project directory:
   ```bash
   supabase init      # only if the project isn't already initialized
   supabase start
   ```
   This boots a local Postgres with the `auth` schema and the
   `anon` / `authenticated` / `service_role` roles already present.

3. **Load the schema and seed data.** Use the connection string that
   `supabase start` prints (the local DB URL):
   ```bash
   psql "$(supabase status -o env | grep DB_URL | cut -d= -f2-)" -f casabe_schema.sql
   psql "$(supabase status -o env | grep DB_URL | cut -d= -f2-)" -f casabe_seed.sql
   ```
   > Do **not** run `00_auth_stub.sql` here — Supabase already provides `auth`.

4. Open local Studio (URL shown by `supabase start`) to browse the data.

If you'd rather treat the schema as a migration, drop `casabe_schema.sql` into
`supabase/migrations/` (timestamp-prefixed) and run `supabase db reset` — it
rebuilds the local DB from migrations + `supabase/seed.sql` every time.

---

## Alternative path: plain Postgres

If you just want a bare Postgres (no Supabase services):

```bash
createdb casabe_dev
psql casabe_dev -f 00_auth_stub.sql     # <-- required on plain Postgres
psql casabe_dev -f casabe_schema.sql
psql casabe_dev -f casabe_seed.sql
```

---

## Testing Row Level Security locally

The whole access model runs on the `members` table: a logged-in user maps to a
tenant and an `app_role` (`hq` | `office` | `driver` | `customer`), and the
helper functions (`current_tenant_id()`, `get_user_role()`, `is_hq()`, …) read
from it. Policies then decide what each role can see.

You can simulate any user from SQL by setting the same session variable
`auth.uid()` reads:

```sql
set role authenticated;
select set_config('request.jwt.claim.sub',
                  '33333333-3333-3333-3333-333333333333', false);  -- the driver

select count(*) from orders;      -- driver sees only their assigned order(s)
select count(*) from box_orders;  -- driver sees only their assigned boxes
reset role;
```

Seeded user IDs:

| Role   | email             | user_id |
|--------|-------------------|---------|
| HQ     | hq@demo.test      | `11111111-1111-1111-1111-111111111111` |
| Office | office@demo.test  | `22222222-2222-2222-2222-222222222222` |
| Driver | driver@demo.test  | `33333333-3333-3333-3333-333333333333` |

(As the `postgres` superuser, RLS is bypassed — switch to `authenticated` as
above to actually exercise the policies.)

---

## Schema at a glance

- **Multi-tenant.** Every table is scoped by `tenant_id`, which points at
  `companies(id)`. `orders` uses a composite primary key `(id, tenant_id)`, so
  the tables that reference orders (`box_orders`, `payments`, `invoices`,
  `messages`) use composite foreign keys on `(order_id, tenant_id)`.
- **Orders are JSONB-heavy.** `orders.data` holds most order fields; the
  promoted columns (office_id, partner_id, coordinates, consent flags) are the
  ones needed for indexing, joins, or policies.
- **Roles:** `hq` (full tenant access), `office` (scoped to their office via
  `get_user_office_ids()`), `driver` (only orders/boxes assigned to them).
- **Append-only / no-delete tables:** `activity_log`, `box_orders`,
  `messages`, `tape_direct_records`, `box_sale_records` have explicit
  `deny … delete` policies.
- **`stripe_events`** is writable only by `service_role` (webhook handler);
  everyone else is blocked.
- The two `_snapshot_*` tables that exist in production are intentionally
  excluded — they're transient backups, not part of the app.

## Keeping this in sync

This file reflects the schema at handoff time. If production changes, the
cleanest way to refresh it is a structure-only dump (no rows):

```bash
supabase db dump --schema public -f casabe_schema.sql
```
