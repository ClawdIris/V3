-- ============================================================================
-- casabe_seed.sql — FAKE development data (safe to share; nothing real here)
-- ----------------------------------------------------------------------------
-- Run AFTER casabe_schema.sql. Gives a developer a working tenant with HQ /
-- office / driver users, a couple offices/partners, and a few orders + boxes.
--
-- All names, phones, emails and IDs are invented. Do not put real customer
-- data in this file.
--
-- NOTE: inserts touch auth.users, which only makes sense locally. The fixed
-- UUIDs below let you log in as these users in your local Supabase Studio or
-- set request.jwt.claim.sub to one of them when testing RLS via SQL.
-- ============================================================================

begin;

-- Fake auth users -----------------------------------------------------------
insert into auth.users (id, email) values
  ('11111111-1111-1111-1111-111111111111', 'hq@demo.test'),
  ('22222222-2222-2222-2222-222222222222', 'office@demo.test'),
  ('33333333-3333-3333-3333-333333333333', 'driver@demo.test')
on conflict (id) do nothing;

-- Tenant --------------------------------------------------------------------
insert into public.companies (id, name, plan, display_name, legal_name, status, tier)
values ('demo-co', 'Demo Logistics Co', 'pilot', 'Demo Logistics', 'Demo Logistics LLC', 'active', 'pilot');

-- Offices -------------------------------------------------------------------
insert into public.offices (id, tenant_id, slug, name, address, phone, commission_model) values
  ('aaaaaaaa-0000-0000-0000-000000000001', 'demo-co', 'miami', 'Miami Office', '100 Demo St, Miami, FL', '+13050000001',
     '{"type":"owned","retain_revenue_percent":100,"office_commission_percent":0}'),
  ('aaaaaaaa-0000-0000-0000-000000000002', 'demo-co', 'orlando', 'Orlando Office', '200 Sample Ave, Orlando, FL', '+14070000002',
     '{"type":"owned","retain_revenue_percent":100,"office_commission_percent":0}');

-- Partners ------------------------------------------------------------------
insert into public.partners (id, tenant_id, slug, name, phone, commission_model) values
  ('bbbbbbbb-0000-0000-0000-000000000001', 'demo-co', 'acme-travel', 'Acme Travel', '+13050000010',
     '{"type":"percentage","percentage":18}'),
  ('bbbbbbbb-0000-0000-0000-000000000002', 'demo-co', 'globex-cargo', 'Globex Cargo', '+13050000011',
     '{"type":"per_box","rates":{"small":5,"medium":8,"large":12}}');

-- Members (links auth users -> tenant + role) -------------------------------
insert into public.members (tenant_id, user_id, role, app_role, display_name, office_id) values
  ('demo-co', '11111111-1111-1111-1111-111111111111', 'owner',      'hq',     'Dana HQ',      null),
  ('demo-co', '22222222-2222-2222-2222-222222222222', 'dispatcher', 'office', 'Omar Office',  'aaaaaaaa-0000-0000-0000-000000000001'),
  ('demo-co', '33333333-3333-3333-3333-333333333333', 'dispatcher', 'driver', 'Dee Driver',   null);

-- Orders --------------------------------------------------------------------
insert into public.orders (id, tenant_id, data, office_id, partner_id, sms_opted_in) values
  ('ORD-1001', 'demo-co',
     '{"customerName":"Sample Customer A","status":"created","totalBoxes":2,"assignedDriverUserId":"33333333-3333-3333-3333-333333333333"}',
     'aaaaaaaa-0000-0000-0000-000000000001', null, true),
  ('ORD-1002', 'demo-co',
     '{"customerName":"Sample Customer B","status":"in_transit","totalBoxes":1}',
     'aaaaaaaa-0000-0000-0000-000000000002', 'bbbbbbbb-0000-0000-0000-000000000001', false),
  ('ORD-1003', 'demo-co',
     '{"customerName":"Sample Customer C","status":"delivered","totalBoxes":3}',
     'aaaaaaaa-0000-0000-0000-000000000001', null, false);

-- Boxes ---------------------------------------------------------------------
insert into public.box_orders (tenant_id, order_id, box_number, office_id, driver_id, box_type, status, barcode) values
  ('demo-co', 'ORD-1001', 1, 'aaaaaaaa-0000-0000-0000-000000000001', '33333333-3333-3333-3333-333333333333', 'standard', 'assigned', 'DEMO-BC-0001'),
  ('demo-co', 'ORD-1001', 2, 'aaaaaaaa-0000-0000-0000-000000000001', '33333333-3333-3333-3333-333333333333', 'standard', 'assigned', 'DEMO-BC-0002'),
  ('demo-co', 'ORD-1002', 1, 'aaaaaaaa-0000-0000-0000-000000000002', null, 'large', 'in_transit', 'DEMO-BC-0003');

-- A couple of log rows so list views aren't empty ---------------------------
insert into public.send_log (tenant_id, order_id, status, channels, source) values
  ('demo-co', 'ORD-1002', 'sent', array['whatsapp'], 'status_update'),
  ('demo-co', 'ORD-1003', 'sent', array['sms'], 'delivered');

commit;
